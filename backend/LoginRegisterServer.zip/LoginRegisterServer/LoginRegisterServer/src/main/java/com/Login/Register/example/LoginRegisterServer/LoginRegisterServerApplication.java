package com.Login.Register.example.LoginRegisterServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginRegisterServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginRegisterServerApplication.class, args);
	}

}
