package com.Login.Register.example.LoginRegisterServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginRegisterServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
