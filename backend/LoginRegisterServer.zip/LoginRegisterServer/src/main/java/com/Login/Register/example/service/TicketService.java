package com.Login.Register.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Login.Register.example.entity.Ticket;
import com.Login.Register.example.repository.TicketRepo;

@Service
public class TicketService {

    @Autowired
    TicketRepo ticketRepo;

    // Book a ticket
    public Ticket bookTicket(Ticket ticket) {
        return ticketRepo.save(ticket);
    }

    // Get all tickets
    public List<Ticket> getAllTickets() {
        return ticketRepo.findAll();
    }
}