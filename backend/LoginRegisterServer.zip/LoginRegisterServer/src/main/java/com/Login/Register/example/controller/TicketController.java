package com.Login.Register.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.Login.Register.example.entity.Ticket;
import com.Login.Register.example.service.TicketService;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class TicketController {

    @Autowired
    TicketService ticketService;

    // Endpoint to book a ticket
    @PostMapping("/bookTicket")
    public Ticket bookTicket(@RequestBody Ticket ticket) {
        return ticketService.bookTicket(ticket);
    }

    // Endpoint to retrieve all tickets
    @GetMapping("/getAllTickets")
    public List<Ticket> getAllTickets() {
        return ticketService.getAllTickets();
    }
}
