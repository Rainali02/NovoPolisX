package com.Login.Register.example.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ticketId;

    private String ticketType; // Either "VIP" or "Regular"
    private int numberOfTickets;

    // Constructors
    public Ticket() {
    }

    public Ticket(String ticketType, int numberOfTickets) {
        this.ticketType = ticketType;
        this.numberOfTickets = numberOfTickets;
    }

    // Getters and Setters
//    public Long getTicketId() {
//        return ticketId;
//    }
//
//    public void setTicketId(Long ticketId) {
//        this.ticketId = ticketId;
//    }

    public String getTicketType() {
        return ticketType;
    }

    public void setTicketType(String ticketType) {
        this.ticketType = ticketType;
    }

    public int getNumberOfTickets() {
        return numberOfTickets;
    }

    public void setNumberOfTickets(int numberOfTickets) {
        this.numberOfTickets = numberOfTickets;
    }
}
