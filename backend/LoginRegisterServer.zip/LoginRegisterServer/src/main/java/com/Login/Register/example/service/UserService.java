package com.Login.Register.example.service;

import java.util.HashMap;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Login.Register.example.entity.Users;
import com.Login.Register.example.repository.UsersRepo;
import com.Login.Register.example.request.LoginRequest;

@Service
public class UserService {
	
	@Autowired(required=true)
	UsersRepo usersRepo;
	
	public HashMap<String, String> addUser(Users email) {
		HashMap<String, String> data = new HashMap<String, String>();
		
		Users us = usersRepo.findById(email.getEmail()).orElse(null);
		System.out.println(us);
		if(us==null) {
			data.put("status", "success");
			usersRepo.save(email);
		} else
			data.put("status", "Email already registered");
		
		return data;
		
	}
	public HashMap<String, String> loginUser(LoginRequest loginRequest) {
		
		HashMap<String, String> data = new HashMap<String, String>();
		
		Users us = usersRepo.findById(loginRequest.getEmailId()).orElse(null);
		if(us == null) {
			data.put("status", "error");
			data.put("data", "Email not registered");
		} else if(!us.getPassword().equals(loginRequest.getPassword())) {
			data.put("status", "error");
			data.put("data", "Invalid password");
		} else {
			data.put("status", "success");
			data.put("data", us.getUsername());
		}
		
		return data;

	}

}